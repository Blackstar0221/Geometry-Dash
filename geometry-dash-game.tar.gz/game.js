// Get canvas and context
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Set canvas size
function resizeCanvas() {
    const container = canvas.parentElement;
    canvas.width = Math.min(900, container.offsetWidth - 40);
    canvas.height = (canvas.width * 9) / 16;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

// Game variables
const game = {
    score: 0,
    gameActive: false,
    gameOver: false,
    speed: 6,
    gravity: 0.6,
    maxSpeed: 12
};

// Player object
const player = {
    x: canvas.width * 0.15,
    y: canvas.height * 0.7,
    width: 30,
    height: 30,
    velocityY: 0,
    isJumping: false,
    jumpPower: 15,
    color: '#00d4ff'
};

// Ground
const ground = {
    y: canvas.height * 0.75,
    height: canvas.height * 0.25,
    color: '#444'
};

// Obstacles array
let obstacles = [];

// Create obstacle
function createObstacle() {
    const obstacleWidth = 30;
    const obstacleHeight = Math.random() * 40 + 30; // Random height between 30-70
    const obstacle = {
        x: canvas.width,
        y: ground.y - obstacleHeight,
        width: obstacleWidth,
        height: obstacleHeight,
        color: '#ff006e'
    };
    obstacles.push(obstacle);
}

// Update game
function update() {
    if (!game.gameActive) return;

    // Apply gravity
    player.velocityY += game.gravity;
    player.y += player.velocityY;

    // Ground collision
    if (player.y + player.height >= ground.y) {
        player.y = ground.y - player.height;
        player.velocityY = 0;
        player.isJumping = false;
    }

    // Update obstacles
    for (let i = obstacles.length - 1; i >= 0; i--) {
        obstacles[i].x -= game.speed;

        // Check collision with player
        if (checkCollision(player, obstacles[i])) {
            endGame();
            return;
        }

        // Remove obstacles that are off screen
        if (obstacles[i].x + obstacles[i].width < 0) {
            obstacles.splice(i, 1);
            game.score += 10;
            updateScore();

            // Increase difficulty every 100 points
            if (game.score % 100 === 0 && game.speed < game.maxSpeed) {
                game.speed += 0.5;
            }
        }
    }

    // Spawn new obstacles
    if (obstacles.length === 0 || obstacles[obstacles.length - 1].x < canvas.width - 200) {
        createObstacle();
    }
}

// Check collision
function checkCollision(rect1, rect2) {
    return (
        rect1.x < rect2.x + rect2.width &&
        rect1.x + rect1.width > rect2.x &&
        rect1.y < rect2.y + rect2.height &&
        rect1.y + rect1.height > rect2.y
    );
}

// Draw everything
function draw() {
    // Clear canvas
    ctx.fillStyle = '#0a0e27';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid background (optional, for style)
    drawGrid();

    // Draw ground
    ctx.fillStyle = ground.color;
    ctx.fillRect(0, ground.y, canvas.width, ground.height);

    // Draw player
    ctx.fillStyle = player.color;
    ctx.fillRect(player.x, player.y, player.width, player.height);

    // Draw glow effect on player
    ctx.shadowColor = player.color;
    ctx.shadowBlur = 10;
    ctx.strokeStyle = player.color;
    ctx.lineWidth = 2;
    ctx.strokeRect(player.x, player.y, player.width, player.height);
    ctx.shadowBlur = 0;

    // Draw obstacles
    obstacles.forEach(obs => {
        ctx.fillStyle = obs.color;
        ctx.fillRect(obs.x, obs.y, obs.width, obs.height);

        // Glow effect
        ctx.shadowColor = obs.color;
        ctx.shadowBlur = 8;
        ctx.strokeStyle = obs.color;
        ctx.lineWidth = 2;
        ctx.strokeRect(obs.x, obs.y, obs.width, obs.height);
        ctx.shadowBlur = 0;
    });
}

// Draw grid background
function drawGrid() {
    const gridSize = 40;
    ctx.strokeStyle = 'rgba(100, 100, 150, 0.1)';
    ctx.lineWidth = 1;

    for (let i = 0; i <= canvas.width; i += gridSize) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, canvas.height);
        ctx.stroke();
    }

    for (let i = 0; i <= canvas.height; i += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(canvas.width, i);
        ctx.stroke();
    }
}

// Update score display
function updateScore() {
    document.getElementById('score').textContent = game.score;
}

// Jump action
function jump() {
    if (!game.isJumping && player.y >= ground.y - player.height - 5) {
        player.velocityY = -game.jumpPower;
        player.isJumping = true;
    }
}

// Start game
function startGame() {
    if (!game.gameActive) {
        game.gameActive = true;
        game.gameOver = false;
        game.score = 0;
        game.speed = 6;
        player.y = ground.y - player.height;
        player.velocityY = 0;
        obstacles = [];
        updateScore();
        document.getElementById('status').textContent = 'Game Running!';
        document.getElementById('status').style.color = '#00ff88';
    }
}

// End game
function endGame() {
    game.gameActive = false;
    game.gameOver = true;
    document.getElementById('status').textContent = `Game Over! Final Score: ${game.score}`;
    document.getElementById('status').style.color = '#ff006e';
}

// Event listeners
document.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
        e.preventDefault();
        if (!game.gameActive && !game.gameOver) {
            startGame();
        } else if (game.gameActive) {
            jump();
        } else if (game.gameOver) {
            startGame();
        }
    }
});

canvas.addEventListener('click', () => {
    if (!game.gameActive && !game.gameOver) {
        startGame();
    } else if (game.gameActive) {
        jump();
    } else if (game.gameOver) {
        startGame();
    }
});

// Game loop
function gameLoop() {
    update();
    draw();
    requestAnimationFrame(gameLoop);
}

// Start the game loop
gameLoop();
